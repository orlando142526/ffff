var canvas = document.getElementById('micanvas');
var ctx = canvas.getContext('2d');
circulo();
circulo2();
circulo3();
circulo4();
circulo5();
function circulo(){
    ctx.beginPath();
    ctx.strokeStyle="blue";
    ctx.fillStyle = "transparent";
    ctx.arc(30,30,30,0,2*Math.PI);
    ctx.fill();
    ctx.stroke();
}
function circulo2(){
    ctx.beginPath();
    ctx.strokeStyle="black";
    ctx.fillStyle = "transparent";
    ctx.arc(95,30,30,0,2*Math.PI);
    ctx.fill();
    ctx.stroke();
}
function circulo3(){
    ctx.beginPath();
    ctx.strokeStyle="red";
    ctx.fillStyle = "transparent";
    ctx.arc(160,30,30,0,2*Math.PI);
    ctx.fill();
    ctx.stroke();
}
function circulo4(){
    ctx.beginPath();
    ctx.strokeStyle="yellow";
    ctx.fillStyle = "transparent";
    ctx.arc(62,70,30,0,2*Math.PI);
    ctx.fill();
    ctx.stroke();
}
function circulo5(){
    ctx.beginPath();
    ctx.strokeStyle="green";
    ctx.fillStyle = "transparent";
    ctx.arc(124,70,30,0,2*Math.PI);
    ctx.fill();
    ctx.stroke();
}